fx_version 'cerulean'
game 'gta5'

--Created by PlayDough

--This file property of SBB City | Owned by PlayDough

--cfx.re join link https://servers.fivem.net/servers/detail/88vomv

--Visit https://discord.gg/QQe38yeJg2 for a great, relaxed non-RP server.

--You may use this file on any server and with any vehicle mod you choose.

--Example fxmanifest.lua file. Keep this file around for converting SP cars to work in FiveM.

-----------------------------------------------------------------------------------------------------
---------------------------------------INSTRUCTIONS--------------------------------------------------
-----------------------------------------------------------------------------------------------------

-----------------------------------------------------
--Edit these to match what is in your "data" folder--
-----------------------------------------------------

-----------------------------------------------------------
--NOTICE: Be sure to create a new folder in you car--------
--folder called 'data' and put ALL of the below------------
--files into this folder. The file architecture should-----
--look like this: -----------------------------------------
--     >resources  -------------------------------------------
--         -->(carNameHere)  ---------------------------------
--          -->stream  ------------------------------------
--              -->ModelName.ytf  -------------------------
--              -->ModelName_hi.ytf  ----------------------
--              -->TextureDictionary.ytd  -----------------
--          -->data  --------------------------------------
--              -->(dataFilesHere)  -----------------------
--        -->fxmanifest.lua  --------------------------------
-----------------------------------------------------------

files {
    'data/vehicles.meta', --Vehicles metadata file
    'data/carvariations.meta', --Carvariations metadata file
    'data/dlctext.meta', --Dlctext metadata file
    'data/handling.meta', --Handling metadat file
    'data/carcols.meta', --Carcols metadata file
    'data/shop_vehicle.meta', --Vehicle shop file
    'data/vehiclelayouts.meta', --Vehicle Layouts file
}

-----------------------------------------------------
--Be sure to edit these to reflect the above paths---
-----------------------------------------------------

data_file 'VEHICLE_METADATA_FILE' 'data/vehicles.meta'
data_file 'VEHICLE_VARIATION_FILE' 'data/carvariations.meta'
data_file 'VEHICLE_CARCOLS_FILE' 'data/carcols.meta'
data_file 'VEHICLE_DLC_TEXT_FILE' 'data/dlctext.meta'
data_file 'VEHICLE_HANDLING_FILE' 'data/handling.meta'
data_file 'VEHICLE_LAYOUTS_FILE' 'data/vehiclelayouts.meta'
data_file 'VEHICLE_SHOP_FILE' 'data/shop_vehicle.meta'
